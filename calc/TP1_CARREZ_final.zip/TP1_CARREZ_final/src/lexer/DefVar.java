package lexer;

public class DefVar implements Token {
    public String toString(){
        return "DEFVAR";
    }
}
