package lexer;

public class If implements Token {
    public String toString(){
        return "IF";
    }
}
