package lexer;

public class LPar implements Token {
    public String toString(){
        return "LPAR";
    }
}
