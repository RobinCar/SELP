package parser;

import eval.State;

import java.io.IOException;

public abstract class AST {
    public abstract String toString();
}