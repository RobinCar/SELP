Système d'exploitation : Linux
Version java : 11.0.1

Avancement : J'ai réalisé la piste verte, tous les test initiaux passent, j'ai juste une erreur que je n'ai pas réussi à gérer.
			J'ai réalisé la piste bleu et les tests passent.
			J'ai commencé la piste rouge mais je n'ai pas eu le temps de la finir.

Gestion erreurs : J'ai l'erreur pour 01 que je n'arrive pas à gérer, sinon j'ai réussi à gérer les autres erreurs en me basant que les tests fournis.

