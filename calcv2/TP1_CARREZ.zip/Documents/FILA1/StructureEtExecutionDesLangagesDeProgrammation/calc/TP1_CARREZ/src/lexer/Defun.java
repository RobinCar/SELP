package lexer;

public class Defun implements Token {
    public String toString(){
        return "DEFUN";
    }
}
