package lexer;

public class EOF implements Token {
	public String toString(){
		return "EOF";
	}
}
