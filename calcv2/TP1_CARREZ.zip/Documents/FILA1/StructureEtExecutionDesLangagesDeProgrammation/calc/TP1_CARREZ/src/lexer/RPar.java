package lexer;

public class RPar implements Token {
    public String toString(){
        return "RPAR";
    }
}
