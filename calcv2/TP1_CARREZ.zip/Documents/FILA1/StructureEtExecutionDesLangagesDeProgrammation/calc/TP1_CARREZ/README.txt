Système d'exploitation : Linux
Version java : 11.0.1

Avancement : J'ai réalisé la piste verte, tous les test initiaux passent, j'ai juste une erreur que je n'ai pas réussi à gérer, et j'ai commencé la piste bleu.

Gestion erreurs : J'ai l'erreur pour 01 que je n'arrive pas à gérer, sinon j'ai réussi à gérer les autres erreurs en me basant que les tests fournis.

