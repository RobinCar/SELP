Avancement : J'ai réalisé la piste verte avec la syntaxe étendue, et j'ai créé les méthodes gen pour les différents éléments.
			 Erreurs de syntaxe avec les UnaryExpression.
			 Je n'ai pas réalisé les tests pour les erreurs.
			 Les tests avec compilation en c ne passent pas (erreur de compilation du fichier en c) pour certains fichiers.
Environnement : Système d'exploitation : Linux
				Version java : 11.0.1
				gcc version 8.2.0
