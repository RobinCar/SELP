#include <stdio.h>
int main () { 
return printf("%d\n",(
if ((21>12)) {
if ((12==21)) {
1
 }else {
2
 }
 }else {
3
 }));
}
