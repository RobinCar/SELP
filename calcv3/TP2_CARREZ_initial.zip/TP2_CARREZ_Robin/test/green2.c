#include <stdio.h>
int main () { 
return printf("%d\n",(
(0+2)));
}
