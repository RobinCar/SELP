#include <stdio.h>
int main () { 
return printf("%d\n",(
false));
}
