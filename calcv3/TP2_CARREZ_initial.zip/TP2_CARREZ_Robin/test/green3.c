#include <stdio.h>
int main () { 
return printf("%d\n",(
(1+(2*3))));
}
