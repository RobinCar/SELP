#include <stdio.h>
int main () { 
return printf("%d\n",(
if ((12==21)) {
12
 }else {
21
 }));
}
