#include <stdio.h>
int main () { 
return printf("%d\n",(
(true||(true&&false))));
}
