#include <stdio.h>
int main () { 
return printf("%d\n",(
if (true) {
12
 }else {
21
 }));
}
